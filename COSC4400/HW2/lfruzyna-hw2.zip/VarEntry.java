public class VarEntry {
  String name;
  int token;
  
  public VarEntry(String n, int t){
    name = n;
    token = t;
  }
}